![Ekran görüntüsü 2023-12-25 214555](https://github.com/ErayKeles/OracleDenemeJava/assets/128937269/6bd00756-de42-4027-b940-8b6933851eff)
![Ekran görüntüsü 2023-12-25 214113](https://github.com/ErayKeles/OracleDenemeJava/assets/128937269/1b57a584-de96-4e49-b487-2cfb05308f37)
![Ekran görüntüsü 2023-12-25 214240](https://github.com/ErayKeles/OracleDenemeJava/assets/128937269/720ee702-7820-44e2-bde6-2c026144d8a6)
